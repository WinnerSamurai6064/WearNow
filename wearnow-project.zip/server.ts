import express from "express";
import { createServer as createViteServer } from "vite";
import multer from "multer";
import { v2 as cloudinary } from "cloudinary";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import AdmZip from "adm-zip";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const upload = multer({ storage: multer.memoryStorage() });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Cloudinary Upload
  app.post("/api/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      // Convert buffer to base64
      const b64 = Buffer.from(req.file.buffer).toString("base64");
      const dataURI = "data:" + req.file.mimetype + ";base64," + b64;

      const result = await cloudinary.uploader.upload(dataURI, {
        folder: "wearnow_products",
      });

      res.json({ url: result.secure_url });
    } catch (error: any) {
      console.error("Cloudinary Upload Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // API Route for Project ZIP Download
  app.get("/api/download-zip", async (req, res) => {
    try {
      const zip = new AdmZip();
      const projectRoot = __dirname;
      
      // Add all files except excluded ones
      const files = fs.readdirSync(projectRoot);
      const exclude = ['node_modules', 'dist', '.git', '.DS_Store', 'package-lock.json'];

      for (const file of files) {
        if (exclude.includes(file)) continue;
        
        const fullPath = path.join(projectRoot, file);
        const stats = fs.statSync(fullPath);
        
        if (stats.isDirectory()) {
          zip.addLocalFolder(fullPath, file);
        } else {
          zip.addLocalFile(fullPath);
        }
      }

      const zipBuffer = zip.toBuffer();
      
      res.set({
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename=wearnow-project.zip',
        'Content-Length': zipBuffer.length
      });
      
      res.send(zipBuffer);
    } catch (error: any) {
      console.error("ZIP Creation Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // API Route to check if Backup feature is enabled
  app.get("/api/backup/status", (req, res) => {
    res.json({ enabled: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
