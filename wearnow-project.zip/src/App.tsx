import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Toaster } from 'react-hot-toast';
import LoadingScreen from '@/src/components/LoadingScreen';
import Navbar from '@/src/components/Navbar';
import Home from '@/src/pages/Home';
import Search from '@/src/pages/Search';
import Cart from '@/src/pages/Cart';
import Profile from '@/src/pages/Profile';
import Admin from '@/src/pages/Admin';
import Auth from '@/src/pages/Auth';
import { useAuth } from '@/src/hooks/useAuth';
import { useCart } from '@/src/hooks/useCart';
import { generateGlassElement, generateGlassCard } from '@/src/lib/gemini';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('home');
  const [bgElement, setBgElement] = useState<string | null>(null);
  const [cardBg, setCardBg] = useState<string | null>(null);
  
  const { user, loading: authLoading } = useAuth();
  const { cart, addToCart, updateQuantity, removeFromCart, totalItems, totalPrice } = useCart();

  useEffect(() => {
    // Regenerate glass elements
    generateGlassElement().then(img => setBgElement(img));
    generateGlassCard().then(img => setCardBg(img));
  }, []);

  useEffect(() => {
    // Artificial delay for the beautiful loading screen
    const timer = setTimeout(() => {
      setLoading(false);
    }, 3000);

    // Safety timeout
    const safetyTimer = setTimeout(() => {
      setLoading(false);
    }, 10000);

    return () => {
      clearTimeout(timer);
      clearTimeout(safetyTimer);
    };
  }, []);

  if (loading || authLoading) {
    return <LoadingScreen />;
  }

  const renderContent = () => {
    if (!user && activeTab !== 'home' && activeTab !== 'search') {
      return <Auth onAuthSuccess={() => setActiveTab('profile')} />;
    }

    switch (activeTab) {
      case 'home': return <Home addToCart={addToCart} />;
      case 'search': return <Search addToCart={addToCart} />;
      case 'cart': return (
        <Cart 
          cart={cart} 
          updateQuantity={updateQuantity} 
          removeFromCart={removeFromCart} 
          totalPrice={totalPrice}
          onCheckout={() => setActiveTab('home')}
        />
      );
      case 'profile': return <Profile user={user} />;
      case 'admin': return (user?.is_admin || user?.can_post) ? <Admin /> : <Home addToCart={addToCart} />;
      default: return <Home addToCart={addToCart} />;
    }
  };

  return (
    <div className="relative min-h-screen bg-bg-primary text-text-primary overflow-x-hidden pb-24 transition-colors duration-500">
      <style>
        {`
          .glass-card {
            ${cardBg ? `background-image: linear-gradient(var(--glass-bg), var(--glass-bg)), url(${cardBg});` : ''}
            background-size: cover;
            background-blend-mode: overlay;
          }
        `}
      </style>

      {/* Background Decorative Elements - More Colorful */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] w-[60%] h-[60%] bg-indigo-500/10 blur-[140px] rounded-full" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[60%] h-[60%] bg-violet-500/10 blur-[140px] rounded-full" />
        <div className="absolute top-[30%] left-[20%] w-[40%] h-[40%] bg-pink-500/5 blur-[100px] rounded-full" />
        
        {bgElement && (
          <motion.img
            key={bgElement}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 0.15, scale: 1 }}
            transition={{ duration: 2 }}
            src={bgElement}
            className="absolute top-[20%] left-[-5%] w-96 h-96 object-contain blur-sm"
            alt=""
          />
        )}
      </div>

      <AnimatePresence mode="wait">
        <motion.main
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="relative z-10 px-4 pt-8 max-w-lg mx-auto"
        >
          {renderContent()}
        </motion.main>
      </AnimatePresence>

      <Navbar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        isAdmin={user?.is_admin}
        user={user}
        cartCount={totalItems}
      />
      
      <Toaster position="top-center" />
    </div>
  );
}
