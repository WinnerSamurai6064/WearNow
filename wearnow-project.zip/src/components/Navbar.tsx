import { motion } from 'motion/react';
import { Home, Search, ShoppingCart, User, Settings } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { UserProfile } from '@/src/types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isAdmin?: boolean;
  user?: UserProfile | null;
  cartCount: number;
}

export default function Navbar({ activeTab, setActiveTab, isAdmin, user, cartCount }: NavbarProps) {
  const tabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'search', icon: Search, label: 'Search' },
    { id: 'cart', icon: ShoppingCart, label: 'Cart', badge: cartCount },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  if (isAdmin || user?.can_post) {
    tabs.push({ id: 'admin', icon: Settings, label: 'Admin' });
  }

  return (
    <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-md z-50">
      <div className="glass-card rounded-2xl p-2 flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "relative p-3 rounded-xl transition-all duration-300",
                isActive ? "text-white shadow-[0_0_15px_rgba(99,102,241,0.5)]" : "text-text-secondary/60 hover:text-electric"
              )}
            >
              <Icon size={24} />
              {tab.badge !== undefined && tab.badge > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-bg-primary">
                  {tab.badge}
                </span>
              )}
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-electric rounded-xl -z-10"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
