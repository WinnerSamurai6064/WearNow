import { motion } from 'motion/react';
import { ShoppingBag } from 'lucide-react';

export default function LoadingScreen() {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="fixed inset-0 z-[100] bg-bg-primary flex flex-col items-center justify-center"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{
          duration: 0.5,
          repeat: Infinity,
          repeatType: "reverse"
        }}
        className="relative"
      >
        <div className="w-24 h-24 rounded-full border-4 border-electric/20 border-t-electric animate-spin" />
        <div className="absolute inset-0 flex items-center justify-center">
          <ShoppingBag className="w-8 h-8 text-electric" />
        </div>
      </motion.div>
      
      <motion.h1
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="mt-8 text-2xl font-bold tracking-widest text-primary"
      >
        WEAR<span className="text-electric">NOW</span>
      </motion.h1>
      
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: 200 }}
        transition={{ duration: 2, ease: "easeInOut" }}
        className="mt-4 h-1 bg-electric/20 rounded-full overflow-hidden"
      >
        <motion.div
          animate={{ x: [-200, 200] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
          className="h-full w-1/2 bg-electric shadow-[0_0_15px_rgba(59,130,246,0.5)]"
        />
      </motion.div>
    </motion.div>
  );
}
