import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, X, Upload, Trash2, Package, DollarSign, FileText, Coins, LogIn } from 'lucide-react';
import { supabase } from '@/src/lib/supabase';
import { Product } from '@/src/types';
import toast from 'react-hot-toast';

interface AdminPortalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminPortal({ isOpen, onClose }: AdminPortalProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Form states
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [category, setCategory] = useState('Apparel');
  const [image, setImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [products, setProducts] = useState<Product[]>([]);

  const adminUser = (import.meta as any).env.VITE_ADMIN_USERNAME || 'WearNow';
  const adminPass = (import.meta as any).env.VITE_ADMIN_PASSWORD || 'specialuser2024';

  useEffect(() => {
    if (isAuthenticated && isOpen) {
      fetchProducts();
    }
  }, [isAuthenticated, isOpen]);

  const fetchProducts = async () => {
    const { data } = await supabase.from('products').select('*').order('created_at', { ascending: false });
    if (data) setProducts(data);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === adminUser && password === adminPass) {
      setIsAuthenticated(true);
      toast.success('Portal Unlocked');
    } else {
      toast.error('Access Denied');
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!image) return toast.error('Image required');
    
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', image);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Upload failed');
      }

      const { url: publicUrl } = await response.json();

      const { error: dbError } = await supabase
        .from('products')
        .insert({
          name,
          description,
          price: parseFloat(price),
          currency,
          category,
          image_url: publicUrl
        });

      if (dbError) throw dbError;

      toast.success('Published!');
      setName('');
      setDescription('');
      setPrice('');
      setImage(null);
      setPreviewUrl(null);
      fetchProducts();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteProduct = async (id: string) => {
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (!error) {
      toast.success('Removed');
      fetchProducts();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-navy/80 backdrop-blur-md"
          />
          
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-md glass-card rounded-3xl overflow-hidden max-h-[90vh] flex flex-col shadow-2xl border border-indigo-500/10"
          >
            <div className="p-6 border-b border-black/5 flex items-center justify-between bg-black/5">
              <div className="flex items-center gap-2">
                <Shield className="text-electric" size={20} />
                <h2 className="font-bold text-primary tracking-tight">Admin Portal</h2>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-black/5 rounded-full transition-colors">
                <X size={20} className="text-text-secondary/50" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
              {!isAuthenticated ? (
                <form onSubmit={handleLogin} className="space-y-4 py-4">
                  <div className="text-center space-y-2 mb-6">
                    <p className="text-sm text-text-secondary/60">Restricted Access Portal</p>
                  </div>
                  <div className="space-y-2">
                    <input 
                      type="text" 
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="input-field"
                      placeholder="Admin ID"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <input 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="input-field"
                      placeholder="Access Key"
                      required
                    />
                  </div>
                  <button 
                    type="submit"
                    className="w-full glass-button bg-electric text-white font-bold flex items-center justify-center gap-2"
                  >
                    Unlock <LogIn size={18} />
                  </button>
                </form>
              ) : (
                <div className="space-y-8">
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-electric uppercase tracking-widest">Post New Item</h3>
                    <form onSubmit={handleUpload} className="space-y-4">
                      <input 
                        type="text" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="input-field"
                        placeholder="Product Name"
                        required
                      />
                      <textarea 
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        className="input-field min-h-[80px]"
                        placeholder="Description"
                        required
                      />
                      <div className="grid grid-cols-2 gap-3">
                        <input 
                          type="number" 
                          value={price}
                          onChange={(e) => setPrice(e.target.value)}
                          className="input-field"
                          placeholder="Price"
                          required
                        />
                        <select 
                          value={currency}
                          onChange={(e) => setCurrency(e.target.value)}
                          className="input-field appearance-none"
                        >
                          <option value="USD">$ USD</option>
                          <option value="EUR">€ EUR</option>
                          <option value="GBP">£ GBP</option>
                          <option value="NGN">₦ NGN</option>
                        </select>
                      </div>
                      
                      <div 
                        className="border-2 border-dashed border-white/10 rounded-2xl p-6 flex flex-col items-center justify-center gap-2 hover:border-electric/50 transition-colors cursor-pointer"
                        onClick={() => document.getElementById('portal-image')?.click()}
                      >
                        {previewUrl ? (
                          <img src={previewUrl} className="w-20 h-20 object-cover rounded-lg" />
                        ) : (
                          <Upload size={24} className="text-gray-cool/30" />
                        )}
                        <span className="text-xs text-gray-cool/50">Upload Image</span>
                        <input id="portal-image" type="file" className="hidden" onChange={handleImageChange} />
                      </div>

                      <button 
                        type="submit" 
                        disabled={loading}
                        className="w-full glass-button bg-electric text-white font-bold"
                      >
                        {loading ? 'Publishing...' : 'Publish to Store'}
                      </button>
                    </form>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-red-500 uppercase tracking-widest">Inventory Control</h3>
                    <div className="grid grid-cols-1 gap-3">
                      {products.map(p => (
                        <div key={p.id} className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5">
                          <div className="flex items-center gap-3">
                            <img src={p.image_url} className="w-10 h-10 rounded-lg object-cover" />
                            <div>
                              <p className="text-xs font-bold text-primary truncate w-32">{p.name}</p>
                              <p className="text-[10px] text-gray-cool/50">{p.currency} {p.price}</p>
                            </div>
                          </div>
                          <button 
                            onClick={() => deleteProduct(p.id)}
                            className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
