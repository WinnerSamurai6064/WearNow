import React, { useState } from 'react';
import { Search as SearchIcon, Filter, Heart, Plus } from 'lucide-react';
import { motion } from 'motion/react';
import { Product } from '@/src/types';
import { formatPrice } from '@/src/lib/utils';
import toast from 'react-hot-toast';

interface SearchProps {
  addToCart: (product: Product) => void;
}

export default function Search({ addToCart }: SearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Product[]>([]);

  // Mock search logic
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setQuery(val);
    
    if (val.length > 2) {
      // Simulate search results
      setResults([
        {
          id: '1',
          name: 'Electric Blue Hoodie',
          description: 'Premium cotton blend hoodie',
          price: 89.99,
          image_url: 'https://picsum.photos/seed/hoodie/400/600',
          category: 'Apparel',
          created_at: new Date().toISOString()
        },
        {
          id: '4',
          name: 'Cool Gray Beanie',
          description: 'Soft knit beanie for cool days',
          price: 25.00,
          image_url: 'https://picsum.photos/seed/beanie/400/600',
          category: 'Accessories',
          created_at: new Date().toISOString()
        }
      ].filter(p => p.name.toLowerCase().includes(val.toLowerCase())));
    } else {
      setResults([]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="relative">
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary/50" size={20} />
        <input
          type="text"
          placeholder="Search collections..."
          value={query}
          onChange={handleSearch}
          className="input-field pl-12"
        />
        <button className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-black/5 rounded-lg text-text-secondary">
          <Filter size={18} />
        </button>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-primary">
          {query ? `Results for "${query}"` : 'Popular Searches'}
        </h3>
        
        {!query && (
          <div className="flex flex-wrap gap-2">
            {['Hoodies', 'Joggers', 'Summer', 'Accessories', 'New'].map(tag => (
              <button key={tag} className="glass-card px-4 py-2 rounded-full text-sm hover:bg-black/5 transition-colors text-text-secondary">
                {tag}
              </button>
            ))}
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          {results.map((product) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="glass-card rounded-2xl overflow-hidden"
            >
              <div className="relative aspect-[3/4]">
                <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <button className="absolute top-2 right-2 p-2 bg-white/40 backdrop-blur-md rounded-full text-primary">
                  <Heart size={16} />
                </button>
              </div>
              <div className="p-3 space-y-1">
                <h4 className="text-sm font-medium text-primary truncate">{product.name}</h4>
                <div className="flex items-center justify-between">
                  <span className="text-electric text-sm font-bold">{formatPrice(product.price)}</span>
                  <button 
                    onClick={() => {
                      addToCart(product);
                      toast.success('Added to cart');
                    }}
                    className="p-1.5 bg-electric rounded-lg text-white"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        {query && results.length === 0 && (
          <div className="text-center py-12 text-text-secondary/50">
            No items found matching your search.
          </div>
        )}
      </div>
    </div>
  );
}
