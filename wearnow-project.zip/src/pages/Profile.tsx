import { useState } from 'react';
import { User, Mail, Package, Heart, LogOut, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { UserProfile } from '@/src/types';
import { supabase } from '@/src/lib/supabase';
import toast from 'react-hot-toast';

interface ProfileProps {
  user: UserProfile | null;
}

export default function Profile({ user }: ProfileProps) {
  const [loading, setLoading] = useState(false);

  const handleSignOut = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signOut();
    if (error) toast.error(error.message);
    else toast.success('Signed out successfully');
    setLoading(false);
  };

  if (!user) return null;

  const menuItems = [
    { icon: Package, label: 'My Orders', count: 0 },
    { icon: Heart, label: 'Wishlist', count: 5 },
    { icon: ChevronRight, label: 'Account Settings' },
    { icon: ChevronRight, label: 'Privacy Policy' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col items-center space-y-4">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-electric/20 border-2 border-electric p-1">
            <div className="w-full h-full rounded-full bg-bg-primary flex items-center justify-center overflow-hidden">
              {user.avatar_url ? (
                <img src={user.avatar_url} alt={user.full_name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <User size={40} className="text-electric" />
              )}
            </div>
          </div>
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute bottom-0 right-0 w-6 h-6 bg-emerald-500 border-2 border-bg-primary rounded-full"
          />
        </div>
        
        <div className="text-center">
          <h2 className="text-2xl font-bold text-primary">{user.full_name || 'User'}</h2>
          <p className="text-text-secondary/60 flex items-center justify-center gap-2">
            <Mail size={14} /> {user.email}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="glass-card p-4 rounded-2xl text-center space-y-1">
          <span className="text-2xl font-bold text-primary">12</span>
          <p className="text-xs text-text-secondary/50 uppercase tracking-widest">Orders</p>
        </div>
        <div className="glass-card p-4 rounded-2xl text-center space-y-1">
          <span className="text-2xl font-bold text-primary">5</span>
          <p className="text-xs text-text-secondary/50 uppercase tracking-widest">Wishlist</p>
        </div>
      </div>

      <div className="glass-card rounded-2xl overflow-hidden">
        {menuItems.map((item, i) => {
          const Icon = item.icon;
          return (
            <button 
              key={i}
              className="w-full flex items-center justify-between p-4 hover:bg-black/5 transition-colors border-b border-black/5 last:border-0"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-black/5 rounded-lg text-text-secondary/70">
                  <Icon size={18} />
                </div>
                <span className="font-medium text-primary">{item.label}</span>
              </div>
              {item.count !== undefined ? (
                <span className="text-xs bg-electric/20 text-electric px-2 py-1 rounded-full font-bold">
                  {item.count}
                </span>
              ) : (
                <ChevronRight size={18} className="text-text-secondary/30" />
              )}
            </button>
          );
        })}
      </div>

      <button 
        onClick={handleSignOut}
        disabled={loading}
        className="w-full glass-button border-red-500/20 text-red-500 font-bold flex items-center justify-center gap-2"
      >
        <LogOut size={20} /> {loading ? 'Signing out...' : 'Sign Out'}
      </button>
    </div>
  );
}
