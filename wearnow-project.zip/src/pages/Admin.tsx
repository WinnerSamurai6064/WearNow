import React, { useState, useEffect } from 'react';
import { Shield, Upload, Plus, Trash2, Package, DollarSign, FileText, CheckCircle, User as UserIcon, X, Coins } from 'lucide-react';
import { motion } from 'motion/react';
import { supabase } from '@/src/lib/supabase';
import { UserProfile, Product } from '@/src/types';
import toast from 'react-hot-toast';

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [category, setCategory] = useState('Apparel');
  const [image, setImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const [users, setUsers] = useState<UserProfile[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [activeTab, setActiveTab] = useState<'upload' | 'users' | 'products'>('upload');

  const adminUser = (import.meta as any).env.VITE_ADMIN_USERNAME || 'WearNow';
  const adminPass = (import.meta as any).env.VITE_ADMIN_PASSWORD || 'specialuser2024';

  useEffect(() => {
    if (isAuthenticated) {
      fetchUsers();
      fetchProducts();
    }
  }, [isAuthenticated]);

  const fetchUsers = async () => {
    const { data } = await supabase.from('profiles').select('*');
    if (data) setUsers(data);
  };

  const fetchProducts = async () => {
    const { data } = await supabase.from('products').select('*').order('created_at', { ascending: false });
    if (data) setProducts(data);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === adminUser && password === adminPass) {
      setIsAuthenticated(true);
      toast.success('Admin access granted');
    } else {
      toast.error('Invalid credentials');
    }
  };

  const toggleVerification = async (userId: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from('profiles')
      .update({ is_verified: !currentStatus })
      .eq('id', userId);
    
    if (!error) {
      toast.success('User verification updated');
      fetchUsers();
    }
  };

  const togglePostPermission = async (userId: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from('profiles')
      .update({ can_post: !currentStatus })
      .eq('id', userId);
    
    if (!error) {
      toast.success('User posting permission updated');
      fetchUsers();
    }
  };

  const deleteProduct = async (productId: string) => {
    const { error } = await supabase.from('products').delete().eq('id', productId);
    if (!error) {
      toast.success('Product deleted');
      fetchProducts();
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!image) return toast.error('Please select an image');
    
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', image);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Upload failed');
      }

      const { url: publicUrl } = await response.json();

      const { error: dbError } = await supabase
        .from('products')
        .insert({
          name,
          description,
          price: parseFloat(price),
          currency,
          category,
          image_url: publicUrl
        });

      if (dbError) throw dbError;

      toast.success('Product uploaded successfully!');
      setName('');
      setDescription('');
      setPrice('');
      setImage(null);
      setPreviewUrl(null);
      fetchProducts();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="space-y-8 py-10">
        <div className="text-center space-y-2">
          <div className="inline-flex p-4 bg-electric/10 rounded-full text-electric mb-4">
            <Shield size={40} />
          </div>
          <h1 className="text-3xl font-bold text-primary">Admin Access</h1>
          <p className="text-gray-cool/50">Restricted area for store management</p>
        </div>

        <form onSubmit={handleLogin} className="glass-card p-6 rounded-3xl space-y-4">
          <div className="space-y-2">
            <label className="text-sm text-gray-cool/50 ml-1">Admin Username</label>
            <input 
              type="text" 
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="input-field"
              placeholder="Username"
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-gray-cool/50 ml-1">Admin Password</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="input-field"
              placeholder="Password"
              required
            />
          </div>
          <button 
            type="submit"
            className="w-full glass-button bg-electric text-white font-bold"
          >
            Unlock Dashboard
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-primary">Dashboard</h1>
        <button 
          onClick={() => setIsAuthenticated(false)}
          className="p-2 bg-black/5 rounded-lg text-text-secondary hover:text-primary"
        >
          Logout
        </button>
      </header>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
        <button 
          onClick={() => setActiveTab('upload')}
          className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${activeTab === 'upload' ? 'bg-electric text-white' : 'bg-black/5 text-text-secondary/60'}`}
        >
          Upload Product
        </button>
        <button 
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${activeTab === 'users' ? 'bg-electric text-white' : 'bg-black/5 text-text-secondary/60'}`}
        >
          Manage Users
        </button>
        <button 
          onClick={() => setActiveTab('products')}
          className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${activeTab === 'products' ? 'bg-electric text-white' : 'bg-black/5 text-text-secondary/60'}`}
        >
          Manage Inventory
        </button>
      </div>

      {activeTab === 'upload' && (
        <div className="glass-card p-6 rounded-3xl space-y-6">
          <div className="flex items-center gap-2 text-electric">
            <Plus size={24} />
            <h2 className="text-xl font-bold">Add New Product</h2>
          </div>

          <form onSubmit={handleUpload} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm text-gray-cool/50 ml-1">Product Name</label>
              <div className="relative">
                <Package className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-cool/30" size={18} />
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input-field pl-12"
                  placeholder="e.g. Electric Blue Hoodie"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-cool/50 ml-1">Description</label>
              <div className="relative">
                <FileText className="absolute left-4 top-4 text-gray-cool/30" size={18} />
                <textarea 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="input-field pl-12 min-h-[100px]"
                  placeholder="Describe the product..."
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm text-gray-cool/50 ml-1">Price</label>
                <div className="relative">
                  <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-cool/30" size={18} />
                  <input 
                    type="number" 
                    step="0.01"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="input-field pl-12"
                    placeholder="0.00"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-gray-cool/50 ml-1">Currency</label>
                <div className="relative">
                  <Coins className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-cool/30" size={18} />
                  <select 
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="input-field pl-12 appearance-none"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="NGN">NGN (₦)</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-cool/50 ml-1">Category</label>
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="input-field appearance-none"
              >
                <option value="Apparel">Apparel</option>
                <option value="Footwear">Footwear</option>
                <option value="Accessories">Accessories</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-cool/50 ml-1">Product Image</label>
              <div 
                className="relative border-2 border-dashed border-white/10 rounded-2xl p-8 flex flex-col items-center justify-center gap-4 hover:border-electric/50 transition-colors cursor-pointer overflow-hidden"
                onClick={() => document.getElementById('image-upload')?.click()}
              >
                {previewUrl ? (
                  <>
                    <img src={previewUrl} className="absolute inset-0 w-full h-full object-cover opacity-50" />
                    <div className="relative z-10 flex flex-col items-center">
                      <Upload size={32} className="text-white" />
                      <span className="text-sm font-medium text-white">Change Image</span>
                    </div>
                  </>
                ) : (
                  <>
                    <Upload size={32} className="text-gray-cool/30" />
                    <span className="text-sm text-gray-cool/50">Tap to upload image</span>
                  </>
                )}
                <input 
                  id="image-upload"
                  type="file" 
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full glass-button bg-electric text-white font-bold flex items-center justify-center gap-2 mt-4"
            >
              {loading ? 'Uploading...' : 'Publish Product'}
              <Upload size={20} />
            </button>
          </form>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="space-y-4">
          {users.map(u => (
            <div key={u.id} className="glass-card p-4 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center">
                  <UserIcon size={20} className="text-gray-cool/50" />
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <p className="font-medium text-primary">{u.full_name || u.email}</p>
                    {u.is_verified && (
                      <div className="verified-badge">
                        <CheckCircle size={10} className="text-white" />
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-gray-cool/50">{u.email}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <div className="relative group/tooltip">
                  <button 
                    onClick={() => toggleVerification(u.id, !!u.is_verified)}
                    className={`p-2 rounded-lg transition-colors ${u.is_verified ? 'bg-electric text-white' : 'bg-white/5 text-gray-cool/50'}`}
                  >
                    <CheckCircle size={18} />
                  </button>
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-navy border border-white/10 text-[10px] text-white rounded whitespace-nowrap opacity-0 group-hover/tooltip:opacity-100 pointer-events-none transition-opacity z-20 shadow-xl">
                    {u.is_verified ? 'Remove verification' : 'Verify user for glowing badge'}
                  </div>
                </div>

                <div className="relative group/tooltip">
                  <button 
                    onClick={() => togglePostPermission(u.id, !!u.can_post)}
                    className={`p-2 rounded-lg transition-colors ${u.can_post ? 'bg-emerald-500 text-white' : 'bg-white/5 text-gray-cool/50'}`}
                  >
                    <Upload size={18} />
                  </button>
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-navy border border-white/10 text-[10px] text-white rounded whitespace-nowrap opacity-0 group-hover/tooltip:opacity-100 pointer-events-none transition-opacity z-20 shadow-xl">
                    {u.can_post ? 'Revoke posting access' : 'Allow user to post products'}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'products' && (
        <div className="grid grid-cols-2 gap-4">
          {products.map(p => (
            <div key={p.id} className="glass-card rounded-2xl overflow-hidden group relative">
              <img src={p.image_url} alt={p.name} className="w-full aspect-square object-cover" />
              <div className="p-3">
                <h4 className="text-sm font-medium text-primary truncate">{p.name}</h4>
                <p className="text-electric font-bold">{p.currency} {p.price}</p>
              </div>
              <button 
                onClick={() => deleteProduct(p.id)}
                className="absolute top-2 right-2 p-2 bg-red-500/80 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
