import React, { useState } from 'react';
import { LogIn, UserPlus, Mail, Lock, User as UserIcon, ArrowRight, Settings, Shield, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '@/src/lib/supabase';
import toast from 'react-hot-toast';

interface AuthProps {
  onAuthSuccess: () => void;
}

export default function Auth({ onAuthSuccess }: AuthProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [settingsEnabled, setSettingsEnabled] = useState(false);

  React.useEffect(() => {
    fetch('/api/backup/status')
      .then(res => res.json())
      .then(data => setSettingsEnabled(data.enabled))
      .catch(() => setSettingsEnabled(false));
  }, []);

  const adminUser = (import.meta as any).env.VITE_ADMIN_USERNAME || 'WearNow';
  const adminPass = (import.meta as any).env.VITE_ADMIN_PASSWORD || 'specialuser2024';

  const handleDownloadZip = async () => {
    setDownloading(true);
    try {
      const response = await fetch('/api/download-zip');
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'wearnow-project.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast.success('Project ZIP downloaded successfully!');
    } catch (error: any) {
      toast.error('Failed to download project ZIP');
    } finally {
      setDownloading(false);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isLogin) {
        // Special check for Admin login via Auth page
        if (username === adminUser && password === adminPass) {
          // For the demo, we'll sign in with a mock admin email or just trigger success
          // In a real app, you'd have a dedicated admin account in Supabase
          const { error } = await supabase.auth.signInWithPassword({ 
            email: 'admin@wearnow.com', 
            password: adminPass 
          });
          if (error) throw error;
          toast.success('Admin logged in!');
        } else {
          // Regular user login (using email for Supabase)
          const { error } = await supabase.auth.signInWithPassword({ 
            email: username.includes('@') ? username : `${username}@wearnow.com`, 
            password 
          });
          if (error) throw error;
          toast.success('Welcome back!');
        }
      } else {
        const { error } = await supabase.auth.signUp({ 
          email, 
          password,
          options: {
            data: { 
              full_name: fullName,
              username: username
            }
          }
        });
        if (error) throw error;
        toast.success('Account created! Please check your email.');
      }
      
      // Give a small delay for Supabase auth state to propagate before triggering redirect
      setTimeout(() => {
        onAuthSuccess();
        setLoading(false);
      }, 500);
    } catch (error: any) {
      toast.error(error.message);
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 py-10 relative">
      {settingsEnabled && (
        <div className="absolute top-0 right-0">
          <button 
            onClick={() => setShowSettings(!showSettings)}
            className="p-3 glass-card rounded-2xl text-text-secondary hover:text-electric transition-all shadow-lg"
            title="System Settings"
          >
            <Settings size={20} className={showSettings ? 'rotate-90 transition-transform' : 'transition-transform'} />
          </button>
        </div>
      )}

      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="glass-card p-6 rounded-3xl border-electric/20 border space-y-4 mb-8"
          >
            <div className="flex items-center gap-2 text-electric font-bold">
              <Shield size={18} />
              <span>Pre-login Configuration</span>
            </div>
            
            <div className="space-y-3">
              <div className="p-3 bg-black/5 rounded-xl space-y-1">
                <p className="text-xs text-text-secondary uppercase tracking-wider font-bold">Admin Access</p>
                <div className="flex justify-between items-center">
                  <code className="text-sm font-mono text-electric">{adminUser}</code>
                  <code className="text-sm font-mono text-text-secondary">••••••••</code>
                </div>
              </div>

              <div className="p-3 bg-black/5 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Download size={16} className="text-text-secondary" />
                    <p className="text-xs text-text-secondary uppercase tracking-wider font-bold">Project Backup</p>
                  </div>
                </div>
                <p className="text-[10px] text-text-secondary/60 leading-relaxed">
                  Download the complete project source code as a ZIP file for manual deployment or backup.
                </p>
                <button 
                  onClick={handleDownloadZip}
                  disabled={downloading}
                  className="w-full py-2 bg-electric/10 hover:bg-electric/20 text-electric rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {downloading ? 'Preparing ZIP...' : 'Download Project ZIP'}
                </button>
              </div>
            </div>
            
            <button 
              onClick={() => setShowSettings(false)}
              className="w-full py-2 text-xs text-text-secondary hover:text-electric transition-colors"
            >
              Close Settings
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold text-primary">
          {isLogin ? 'Welcome Back' : 'Create Account'}
        </h1>
        <p className="text-text-secondary">
          {isLogin ? 'Sign in to access your premium collection' : 'Join the WearNow community today'}
        </p>
      </div>

      <div className="glass-card p-6 rounded-3xl space-y-6">
        <div className="flex p-1 bg-black/5 rounded-xl">
          <button 
            onClick={() => setIsLogin(true)}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-all ${isLogin ? 'bg-electric text-white shadow-lg' : 'text-text-secondary/60'}`}
          >
            <LogIn size={18} /> Login
          </button>
          <button 
            onClick={() => setIsLogin(false)}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-all ${!isLogin ? 'bg-electric text-white shadow-lg' : 'text-text-secondary/60'}`}
          >
            <UserPlus size={18} /> Sign Up
          </button>
        </div>

        <form onSubmit={handleAuth} className="space-y-4">
          {!isLogin && (
            <>
              <div className="space-y-2">
                <label className="text-sm text-gray-cool/50 ml-1">Full Name</label>
                <div className="relative">
                  <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-cool/30" size={18} />
                  <input 
                    type="text" 
                    placeholder="John Doe"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="input-field pl-12"
                    required={!isLogin}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-gray-cool/50 ml-1">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-cool/30" size={18} />
                  <input 
                    type="email" 
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="input-field pl-12"
                    required={!isLogin}
                  />
                </div>
              </div>
            </>
          )}

          <div className="space-y-2">
            <label className="text-sm text-gray-cool/50 ml-1">Username</label>
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-cool/30" size={18} />
              <input 
                type="text" 
                placeholder={isLogin ? "Username or Email" : "Choose a username"}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="input-field pl-12"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-cool/50 ml-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-cool/30" size={18} />
              <input 
                type="password" 
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-field pl-12"
                required
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full glass-button bg-electric text-white font-bold flex items-center justify-center gap-2 mt-4"
          >
            {loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Create Account')}
            <ArrowRight size={20} />
          </button>
        </form>
      </div>
      
      <div className="text-center">
        <button className="text-sm text-gray-cool/50 hover:text-electric transition-colors">
          Forgot password?
        </button>
      </div>
    </div>
  );
}
