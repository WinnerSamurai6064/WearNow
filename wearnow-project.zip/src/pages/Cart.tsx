import { ShoppingBag, Trash2, Plus, Minus, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { CartItem } from '@/src/types';
import { formatPrice } from '@/src/lib/utils';
import toast from 'react-hot-toast';

interface CartProps {
  cart: CartItem[];
  updateQuantity: (id: string, delta: number) => void;
  removeFromCart: (id: string) => void;
  totalPrice: number;
  onCheckout: () => void;
}

export default function Cart({ cart, updateQuantity, removeFromCart, totalPrice, onCheckout }: CartProps) {
  const handleCheckout = () => {
    toast.success('Order placed successfully!');
    onCheckout();
  };

  if (cart.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 space-y-6">
        <div className="w-24 h-24 bg-black/5 rounded-full flex items-center justify-center">
          <ShoppingBag size={40} className="text-text-secondary/30" />
        </div>
        <div className="text-center">
          <h2 className="text-xl font-bold text-primary">Your cart is empty</h2>
          <p className="text-text-secondary mt-2">Looks like you haven't added anything yet.</p>
        </div>
        <button 
          onClick={onCheckout}
          className="glass-button bg-electric text-white font-bold"
        >
          Start Shopping
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-primary">My Cart</h1>

      <div className="space-y-4">
        {cart.map((item) => (
          <motion.div
            key={item.id}
            layout
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-card p-4 rounded-2xl flex gap-4"
          >
            <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
              <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            
            <div className="flex-1 space-y-2">
              <div className="flex justify-between">
                <h3 className="font-medium text-primary">{item.name}</h3>
                <button 
                  onClick={() => removeFromCart(item.id)}
                  className="text-text-secondary/50 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={18} />
                </button>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-electric font-bold">{formatPrice(item.price)}</span>
                
                <div className="flex items-center gap-3 bg-black/5 rounded-lg p-1">
                  <button 
                    onClick={() => updateQuantity(item.id, -1)}
                    className="p-1 hover:bg-black/10 rounded transition-colors"
                  >
                    <Minus size={14} />
                  </button>
                  <span className="text-sm font-bold w-4 text-center text-primary">{item.quantity}</span>
                  <button 
                    onClick={() => updateQuantity(item.id, 1)}
                    className="p-1 hover:bg-black/10 rounded transition-colors"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="glass-card p-6 rounded-2xl space-y-4">
        <h3 className="text-lg font-bold text-primary mb-4">Payment Method</h3>
        <div className="space-y-4">
          <div className="relative">
            <label className="text-xs text-text-secondary/50 ml-1">Card Number</label>
            <input 
              type="text" 
              placeholder="0000 0000 0000 0000"
              className="input-field"
              defaultValue="4242 4242 4242 4242"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="relative">
              <label className="text-xs text-text-secondary/50 ml-1">Expiry Date</label>
              <input 
                type="text" 
                placeholder="MM/YY"
                className="input-field"
                defaultValue="12/26"
              />
            </div>
            <div className="relative">
              <label className="text-xs text-text-secondary/50 ml-1">CVV</label>
              <input 
                type="password" 
                placeholder="***"
                className="input-field"
                defaultValue="123"
              />
            </div>
          </div>
        </div>

        <div className="h-px bg-black/10 my-6" />

        <div className="flex justify-between text-text-secondary">
          <span>Subtotal</span>
          <span>{formatPrice(totalPrice)}</span>
        </div>
        <div className="flex justify-between text-text-secondary">
          <span>Shipping</span>
          <span className="text-emerald-600">Free</span>
        </div>
        <div className="h-px bg-black/10" />
        <div className="flex justify-between text-xl font-bold text-primary">
          <span>Total</span>
          <span>{formatPrice(totalPrice)}</span>
        </div>
        
        <button 
          onClick={handleCheckout}
          className="w-full glass-button bg-electric text-white font-bold flex items-center justify-center gap-2 mt-4"
        >
          Checkout <ArrowRight size={20} />
        </button>
      </div>
    </div>
  );
}
