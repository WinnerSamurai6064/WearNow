import React, { useState, useEffect } from 'react';
import { ShoppingBag, Heart, Plus, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { supabase } from '@/src/lib/supabase';
import { Product, Like } from '@/src/types';
import { formatPrice } from '@/src/lib/utils';
import toast from 'react-hot-toast';
import { useAuth } from '@/src/hooks/useAuth';
import AdminPortal from '@/src/components/AdminPortal';

interface HomeProps {
  addToCart: (product: Product) => void;
}

export default function Home({ addToCart }: HomeProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [likes, setLikes] = useState<Like[]>([]);
  const [loading, setLoading] = useState(true);
  const [isPortalOpen, setIsPortalOpen] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    fetchProducts();
    if (user) fetchLikes();
  }, [user]);

  const fetchProducts = async () => {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error) setProducts(data || []);
    setLoading(false);
  };

  const fetchLikes = async () => {
    const { data } = await supabase
      .from('likes')
      .select('*')
      .eq('user_id', user?.id);
    if (data) setLikes(data);
  };

  const toggleLike = async (productId: string) => {
    if (!user) return toast.error('Please login to like items');

    const existingLike = likes.find(l => l.product_id === productId);

    if (existingLike) {
      const { error } = await supabase.from('likes').delete().eq('id', existingLike.id);
      if (!error) {
        setLikes(prev => prev.filter(l => l.id !== existingLike.id));
      }
    } else {
      const { data, error } = await supabase
        .from('likes')
        .insert({ user_id: user.id, product_id: productId })
        .select()
        .single();
      
      if (!error && data) {
        setLikes(prev => [...prev, data]);
        toast.success('Added to favorites');
      }
    }
  };

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-medium text-electric uppercase tracking-widest">Premium Collection</h2>
            <div 
              className="verified-badge cursor-pointer"
              onDoubleClick={() => setIsPortalOpen(true)}
              title="Double click for portal"
            >
              <CheckCircle size={10} className="text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-primary">WearNow</h1>
        </div>
        <div className="glass-card p-3 rounded-full">
          <ShoppingBag className="text-electric" size={24} />
        </div>
      </header>

      <AdminPortal isOpen={isPortalOpen} onClose={() => setIsPortalOpen(false)} />

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-semibold text-primary">New Arrivals</h3>
          <button className="text-sm text-electric font-medium">View All</button>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="glass-card h-64 rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {products.map((product) => {
              const isLiked = likes.some(l => l.product_id === product.id);
              return (
                <motion.div
                  key={product.id}
                  whileHover={{ y: -5 }}
                  className="glass-card rounded-2xl overflow-hidden group"
                >
                  <div className="relative aspect-[3/4] overflow-hidden">
                    <img 
                      src={product.image_url} 
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                    <button 
                      onClick={() => toggleLike(product.id)}
                      className={`absolute top-3 right-3 p-2 backdrop-blur-md rounded-full transition-colors ${isLiked ? 'bg-red-500 text-white' : 'bg-white/40 text-primary hover:text-red-500'}`}
                    >
                      <Heart size={18} fill={isLiked ? "currentColor" : "none"} />
                    </button>
                  </div>
                  <div className="p-4 space-y-2">
                    <h4 className="font-medium text-primary truncate">{product.name}</h4>
                    <div className="flex items-center justify-between">
                      <span className="text-electric font-bold">
                        {product.currency || '$'} {product.price}
                      </span>
                      <button 
                        onClick={() => handleAddToCart(product)}
                        className="p-2 bg-electric rounded-lg text-white shadow-[0_0_10px_rgba(59,130,246,0.3)] active:scale-90 transition-transform"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
