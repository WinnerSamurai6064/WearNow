import { useState, useEffect } from 'react';
import { supabase } from '@/src/lib/supabase';
import { UserProfile } from '@/src/types';

export function useAuth() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (userId: string, email: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (data) {
        setUser({
          ...data,
          is_admin: data.email === 'admin@wearnow.com' || data.is_admin
        });
      } else {
        setUser({
          id: userId,
          email: email,
          is_admin: email === 'admin@wearnow.com'
        });
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      setUser({
        id: userId,
        email: email,
        is_admin: email === 'admin@wearnow.com'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const checkSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          await fetchProfile(session.user.id, session.user.email!);
        } else {
          setLoading(false);
        }
      } catch (error) {
        console.error('Auth session error:', error);
        setLoading(false);
      }
    };

    checkSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
        await fetchProfile(session.user.id, session.user.email!);
      } else {
        setUser(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user) setLoading(false);
  }, [user]);

  return { user, loading };
}
