import { GoogleGenAI } from "@google/genai";

// Fallback high-quality glass textures in case of API quota limits
const FALLBACK_ELEMENTS = [
  "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1635776062127-d379bfcba9f8?q=80&w=1000&auto=format&fit=crop"
];

const FALLBACK_CARDS = {
  dark: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=1000&auto=format&fit=crop",
  light: "https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=1000&auto=format&fit=crop"
};

// Simple in-memory and localStorage cache to reduce API calls
const getCachedData = (key: string) => {
  try {
    const cached = localStorage.getItem(key);
    if (cached) {
      const { data, timestamp } = JSON.parse(cached);
      // Cache valid for 24 hours
      if (Date.now() - timestamp < 24 * 60 * 60 * 1000) {
        return data;
      }
    }
  } catch (e) {
    return null;
  }
  return null;
};

const setCachedData = (key: string, data: string) => {
  try {
    localStorage.setItem(key, JSON.stringify({ data, timestamp: Date.now() }));
  } catch (e) {
    // Silently fail if storage is full
  }
};

export const generateGlassElement = async () => {
  const cacheKey = 'gemini_glass_element';
  const cached = getCachedData(cacheKey);
  if (cached) return cached;

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
  
  const prompts = [
    'Abstract glassmorphism background element, translucent frosted glass shards with soft electric blue #3B82F6 and deep navy #0F172A gradients, high quality, minimalist, 4k resolution, clean edges',
    'Futuristic glass panels floating in a deep navy void, glowing electric blue edges, soft cool gray reflections, cinematic lighting, 4k',
    'Minimalist geometric glass shapes, frosted texture, deep navy background, electric blue accent lighting, elegant design, 4k'
  ];

  const randomPrompt = prompts[Math.floor(Math.random() * prompts.length)];
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: randomPrompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        const b64 = `data:image/png;base64,${part.inlineData.data}`;
        setCachedData(cacheKey, b64);
        return b64;
      }
    }
  } catch (error: any) {
    console.warn('Gemini API Limit Reached, using fallback element:', error.message);
  }
  
  // Return a random high-quality fallback if API fails
  return FALLBACK_ELEMENTS[Math.floor(Math.random() * FALLBACK_ELEMENTS.length)];
};

export const generateGlassCard = async () => {
  const cacheKey = `gemini_glass_card_light`;
  const cached = getCachedData(cacheKey);
  if (cached) return cached;

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
  
  const prompt = 'High-quality frosted glass texture for a UI card, vibrant indigo and soft violet gradients, subtle light reflections, translucent, minimalist, 4k, clean aesthetic, colorful';

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        const b64 = `data:image/png;base64,${part.inlineData.data}`;
        setCachedData(cacheKey, b64);
        return b64;
      }
    }
  } catch (error: any) {
    console.warn('Gemini API Limit Reached, using fallback card:', error.message);
  }
  
  return FALLBACK_CARDS.light;
};
