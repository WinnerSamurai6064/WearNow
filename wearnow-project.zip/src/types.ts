export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  image_url: string;
  category: string;
  created_at: string;
  user_id?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface UserProfile {
  id: string;
  email: string;
  full_name?: string;
  avatar_url?: string;
  is_admin?: boolean;
  is_verified?: boolean;
  can_post?: boolean;
}

export interface Like {
  id: string;
  user_id: string;
  product_id: string;
}
